﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase05;

namespace App1 {

    class Program {

        static void Main(string[] args) {

            Tinta tint = new Tinta();
            Tinta tint2 = new Tinta(ConsoleColor.Green);
            Tinta tint3 = new Tinta(ETipoTinta.ConBrillito);
            Tinta tint4 = new Tinta(ConsoleColor.Magenta, ETipoTinta.China);

            Console.WriteLine(Tinta.Mostrar(tint));
            Console.WriteLine(Tinta.Mostrar(tint2));
            Console.WriteLine(Tinta.Mostrar(tint3));
            Console.WriteLine(Tinta.Mostrar(tint4));

            if (tint == tint3) {

                Console.WriteLine("Son iguales");

            }
            else {

                Console.WriteLine("Son distintos");

            }

            Console.Write((string)tint);

            Console.Read();

        }

    }

}
