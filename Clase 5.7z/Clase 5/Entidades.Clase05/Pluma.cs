﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase05 {

    class Pluma {

        private string _Marca;
        private Tinta _Tinta;
        private int _Cantidad;

        public Pluma() {

            this._Marca = "Sin marca";
            this._Tinta = null;
            this._Cantidad = 0;

        }

        public Pluma(string marca) : this() {

            this._Marca = marca;

        }

        public Pluma(Tinta tinta) : this() {

            this._Tinta = tinta;

        }


        public Pluma(int cantidad) : this() {

            this._Cantidad = cantidad;

        }

        public Pluma(string marca, Tinta tinta) : this(marca) {

            this._Tinta = tinta;

        }

        public Pluma(string marca, int cantidad) : this(marca) {

            this._Cantidad = cantidad;
        
        }

        public Pluma(Tinta tinta, int cantidad) : this(tinta) {

            this._Cantidad = cantidad;
        
        }

        public Pluma(string marca, Tinta tinta, int cantidad) : this(marca, tinta) {

            this._Cantidad = cantidad;

        }

        private string Mostrar() {

            return "Marca: " + this._Marca + "\n" + Tinta.Mostrar(this._Tinta) + "\nCantidad: " + this._Cantidad;

        }

        public static bool operator == (Pluma pluma, Tinta tinta) {

            return pluma._Tinta == tinta;
        
        }

        public static bool operator != (Pluma pluma, Tinta tinta) {

            return pluma._Tinta != tinta;

        }

        public static Pluma operator + (Pluma pluma, Tinta tinta) {

            if (pluma == tinta && pluma._Cantidad < 100) {

                pluma._Cantidad++;

            }

            return pluma;

        }

        public static Pluma operator - (Pluma pluma, Tinta tinta) {

            if (pluma == tinta && pluma._Cantidad > 0) {

                pluma._Cantidad--;

            }

            return pluma;

        }

        public static implicit operator string (Pluma pluma) {

            return pluma.Mostrar();

        } 

    }

}
