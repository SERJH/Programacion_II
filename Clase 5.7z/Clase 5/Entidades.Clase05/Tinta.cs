﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase05 {

    public class Tinta {

        private ConsoleColor _color;
        private ETipoTinta _tinta;

        public Tinta() {

            this._color = ConsoleColor.Black;
            this._tinta = ETipoTinta.Comun;

        }

        public Tinta(ConsoleColor color):this() {

            this._color = color;

        }

        public Tinta(ETipoTinta tinta):this() {

            this._tinta = tinta;

        }

        public Tinta(ConsoleColor color, ETipoTinta tinta):this(color) {

            this._tinta = tinta;

        }

        private string Mostrar() {

            return "Tipo de tinta: " + this._tinta.ToString() + "\nColor de tinta: " + this._color.ToString();

        }

        static public string Mostrar(Tinta tinta) {

            return tinta.Mostrar();

        }

        public static bool operator == (Tinta tinta1, Tinta tinta2) {

            return (tinta1._color == tinta2._color) && (tinta1._tinta == tinta2._tinta);

        }

        public static bool operator != (Tinta tinta1, Tinta tinta2) {

            return !(tinta1 == tinta2);

        }

/*        public static explicit operator string (Tinta tinta) {

            return tinta.Mostrar();

        }*/

        public static implicit operator string(Tinta tinta) {

            return tinta._tinta.ToString();

        }

    }
}
