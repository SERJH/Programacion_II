﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.Entidad {

    public class Paleta {

        private Tempera[] _Colores;
        private int _CantMaximaColores;

        private Paleta():this(5) {

            
        }

        private Paleta(int cantidad) {

            this._Colores = new Tempera[cantidad];
            this._CantMaximaColores = cantidad;

        }

        public static implicit operator Paleta (int cant) { 

            return new Paleta(cant);

        }

        private string Mostrar() {

            string temperas = "";

            foreach(Tempera i in this._Colores) {
            
                temperas += Tempera.Mostrar(i);

            }

            return temperas;

        }

        public static explicit operator string (Paleta paleta) {

            return paleta.Mostrar();

        }

    }

}
