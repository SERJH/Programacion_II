﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Testeo {

    class Program {

        static void Main(string[] args) {

            Privado aPrivado = new Privado(300000, 800, 5);
            Comercial aComercial = new Comercial(200000, 600, 100);

            Console.WriteLine("Impuestos privado: {0:C}", aPrivado.CalcularImpuestos());
            Console.WriteLine("Impuestos comercial: {0:C}", aComercial.CalcularImpuestos());

            Console.Read();

        }

    }

}
