﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class Auto {

        private string _marca;
        private string _color;

        public string Color {

            get {

                return this._color;

            }
            
        }

        public string Marca {

            get {

                return this._marca;

            }

        }

        public Auto() {

            this._color = "Negro";
            this._marca = "Honda";

        }

        public Auto(string color, string marca) {

            this._color = color;
            this._marca = marca;

        }

        public override bool Equals(object obj) {

            return (obj is Auto) &&
                   ((Auto)obj) == ((Auto)obj);
        
        }

        public static bool operator ==(Auto autoUno, Auto autoDos) {

            return (autoUno.Color == autoDos.Color &&
                    autoUno.Marca == autoDos.Marca);

        }

        public static bool operator !=(Auto autoUno, Auto autoDos) {

            return !(autoUno == autoDos);

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("Marca: ");
            sb.AppendLine(this.Marca);
            sb.Append("Color: ");
            sb.AppendLine(this.Color);

            return sb.ToString();
       
        }

    }

}
