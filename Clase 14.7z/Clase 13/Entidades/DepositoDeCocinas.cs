﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class DepositoDeCocinas {

        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public DepositoDeCocinas(int capacidad) {

            this._lista = new List<Cocina>();
            this._capacidadMaxima = capacidad;

        }

        public static bool operator +(DepositoDeCocinas deposito, Cocina cocina) {

            bool retorno = false;

            if (deposito._lista.Count < deposito._capacidadMaxima) {

                deposito._lista.Add(cocina);
                retorno = true;

            }

            return retorno;

        }

        public int GetIndice(Cocina cocina) {

            int index = 0;
            bool encontrado = false;

            foreach (Cocina i in this._lista) {

                if (i == cocina) {

                    encontrado = true;
                    break;

                }

                index++;

            }

            if (encontrado) {

                return index;

            } else {

                return -1;

            }

        }

        public static bool operator -(DepositoDeCocinas deposito, Cocina cocina) {

            bool retorno = false;
            int index = deposito.GetIndice(cocina);

            if (index != -1) {

                deposito._lista.RemoveAt(index);
                retorno = true;

            }

            return retorno;

        }

        public bool Agregar(Cocina cocina) {

            return (this + cocina);

        }

        public bool Remover(Cocina cocina) {

            return (this - cocina);

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nCapacidad: ");
            sb.AppendLine(this._capacidadMaxima.ToString());
            sb.AppendLine("\nLista de cocinas:\n");

            foreach (Cocina i in this._lista) {

                sb.AppendLine(i.ToString());

            }

            return sb.ToString();

        }

    }

}
