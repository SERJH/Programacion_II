﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class DepositoDeAutos {

        private int _capacidadMaxima;
        private List<Auto> _lista;

        public DepositoDeAutos(int capacidad) {

            this._lista = new List<Auto>();
            this._capacidadMaxima = capacidad;

        }

        public static bool operator +(DepositoDeAutos deposito, Auto auto) {

            bool retorno = false;

            if (deposito._lista.Count < deposito._capacidadMaxima) {

                deposito._lista.Add(auto);
                retorno = true;

            }

            return retorno;

        }

        private int GetIndice(Auto auto) {

            int index = 0;
            bool encontrado = false;

            foreach (Auto i in this._lista) {

                if (i == auto) {

                    encontrado = true;
                    break;

                }

                index++;

            }

            if (encontrado) {

                return index;

            } else {
              
                return -1;
            
            }

        }

        public static bool operator -(DepositoDeAutos deposito, Auto auto) {

            int index = deposito.GetIndice(auto);
            bool retorno = false;

            if (index != -1) {

                deposito._lista.RemoveAt(index);
                retorno = true;

            }

            return retorno;

        }

        public bool Agregar(Auto auto) {

            return (this + auto);

        }

        public bool Remover(Auto auto) {

            return (this - auto);

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nCapacidad: ");
            sb.AppendLine(this._capacidadMaxima.ToString());
            sb.AppendLine("\nLista de autos:\n");

            foreach (Auto i in this._lista) {

                sb.AppendLine(i.ToString());

            }

            return sb.ToString();
        
        }

    }

}
