﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class Cocina {

        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo {

            get { return this._codigo; }
            
        }

        public bool EsIndustrial {

            get { return this._esIndustrial; }

        }

        public double Precio {

            get { return this._precio; }

        }

        public Cocina() {

            this._codigo = 101;
            this._precio = 15000;
            this._esIndustrial = false;

        }

        public Cocina(int codigo, double precio, bool esIndustrial) {

            this._codigo = codigo;
            this._precio = precio;
            this._esIndustrial = esIndustrial;

        }

        public static bool operator ==(Cocina cocinaUno, Cocina cocinaDos) {

            return (cocinaUno.Codigo == cocinaDos.Codigo);

        }

        public static bool operator !=(Cocina cocinaUno, Cocina cocinaDos) {

            return !(cocinaUno == cocinaDos);

        }

        public override bool Equals(object obj) {
            
            return (obj is Cocina &&
                   ((Cocina)obj) == this);
        
        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("Codigo: ");
            sb.AppendLine(this.Codigo.ToString());
            sb.Append("Precio: ");
            sb.AppendLine(this.Precio.ToString());
            sb.AppendFormat("Es industrial: {0}", this.EsIndustrial ? "SI" : "NO");

            return sb.ToString();

        }

    }

}
