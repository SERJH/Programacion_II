﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class Deposito<T> where T : new() {

        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito() {

            this._lista = new List<T>();

        }

        public Deposito(int capacidad):this() {

            this._lista = new List<T>();

            try {

                if (capacidad > 50) {

                    throw new Exception("La capacidad máxima no puede ser mayor a 50");

                } else if (capacidad < 1) {

                    throw new Exception("La capacidad máxima no puede ser menor a 1");

                } else {

                    this._capacidadMaxima = capacidad;

                }

            }

            catch {

                if (capacidad > 50) {

                    this._capacidadMaxima = 50;

                } else {

                    this._capacidadMaxima = 1;

                }

            }

        }

        public List<T> Lista {

            get {

                return this._lista;

            }

        }

        public int Capacidad {

            get {

                return this._capacidadMaxima - this._lista.Count;

            }

        }

        public static bool operator +(Deposito<T> deposito, T item) {

            bool retorno = false;

            if (deposito._lista.Count < deposito._capacidadMaxima) {

                deposito._lista.Add(item);
                retorno = true;

            } else {

                throw new DepositoLlenoException("El deposito ya esta lleno");

            }

            return retorno;

        }

        private int GetIndice(T item) {

            int index = 0;
            bool encontrado = false;

            foreach (T i in this._lista) {

                if (i.Equals(item)) {

                    encontrado = true;
                    break;

                }

                index++;

            }

            if (encontrado) {

                return index;

            } else {
              
                return -1;
            
            }

        }

        public static bool operator -(Deposito<T> deposito, T item) {

            int index = deposito.GetIndice(item);
            bool retorno = false;

            if (index != -1) {

                deposito._lista.RemoveAt(index);
                retorno = true;

            }

            return retorno;

        }

        public bool Agregar(T item) {

            return (this + item);

        }

        public bool Remover(T item) {

            return (this - item);

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nCapacidad: ");
            sb.AppendLine(this._capacidadMaxima.ToString());
            sb.Append("\nLista de ");
            sb.AppendLine(typeof(T).Name);

            foreach (T i in this._lista) {

                sb.AppendLine(i.ToString());

            }

            return sb.ToString();
        
        }

    }

}
