﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Colecciones {

    public class Tempera {

        private ConsoleColor _Color;
        private string _Marca;
        private int _Cantidad;

        public Tempera(ConsoleColor color, string marca, int cantidad) {

            this._Color = color;
            this._Marca = marca;
            this._Cantidad = cantidad;

        }

        private string Mostrar() {

            return "\nColor: " + this._Color +
                   "\nMarca: " + this._Marca + 
                   "\nCantidad: " + this._Cantidad;

        }

        public static string Mostrar(Tempera tempera) {

            return tempera.Mostrar();

        }

        public static bool operator == (Tempera t1, Tempera t2) {

            return (t1._Color == t2._Color) && 
                   (t1._Marca == t2._Marca);

        }

        public static bool operator != (Tempera t1, Tempera t2) {

            return !(t1 == t2);

        }

        public static Tempera operator +(Tempera tempera, double cantidad) {

            Tempera auxTempera = new Tempera(tempera._Color, tempera._Marca, tempera._Cantidad);


            if (cantidad > 0 && auxTempera._Cantidad < 100) {

                if (!((auxTempera._Cantidad + (int)cantidad) > 100)) {

                    auxTempera._Cantidad += (int)cantidad;

                } 

            }

            return auxTempera;

        }

        public static implicit operator int (Tempera temp) {

            return temp._Cantidad;

        }

    }

}
