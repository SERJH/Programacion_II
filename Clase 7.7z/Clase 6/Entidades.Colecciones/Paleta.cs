﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Colecciones {

    public class Paleta {

        private List<Tempera> _Colores;
        private int _CantMaximaColores;

        private Paleta():this(5) {

            
        }

        private Paleta(int cantidad) {

            this._Colores = new List<Tempera>();
            this._CantMaximaColores = cantidad;

        }

        public static implicit operator Paleta (int cant) { 

            return new Paleta(cant);

        }

        private string Mostrar() {

            string temperas = "";

            foreach(Tempera i in this._Colores) {
            
                temperas += Tempera.Mostrar(i);

            }

            return temperas;

        }

        public static explicit operator string (Paleta paleta) {

            return paleta.Mostrar();

        }

        public static bool operator == (Paleta paleta, Tempera tempera) {

            bool devolver = false;

            if (paleta.buscarIndice(tempera) != -1) {

                devolver = true;

            }

            return devolver;

        }


        public static bool operator != (Paleta paleta, Tempera tempera) {

            return !(paleta == tempera);

        }



        public static Paleta operator + (Paleta paleta, Tempera tempera) {

            int index = 0;
            Paleta auxPaleta = paleta._CantMaximaColores;

            auxPaleta = paleta;

            index = auxPaleta.buscarIndice(tempera);

            if (index != -1) {

                auxPaleta._Colores[index] = auxPaleta._Colores[index] + (int)tempera;

            } else {

                index = auxPaleta.buscarIndice();

                if (index != -1) {

                    auxPaleta._Colores[index] = tempera;

                }

            }

            return auxPaleta;

        }

        public static Paleta operator - (Paleta paleta, Tempera tempera) {

            int index = 0;
            Paleta auxPaleta = paleta._CantMaximaColores;

            auxPaleta = paleta;

            index = auxPaleta.buscarIndice(tempera);

            if (index != -1) {

                auxPaleta._Colores[index] = null;

            }

            return auxPaleta;

        }


        public static Paleta operator + (Paleta paleta, Paleta paletaDos) {

            Paleta auxPaleta = paleta._CantMaximaColores + paletaDos._CantMaximaColores;
            int contador;

            auxPaleta = paleta;

            for (contador = 0; contador < paletaDos._CantMaximaColores; contador++) {

                auxPaleta = auxPaleta + paletaDos._Colores[contador];

            }

            return auxPaleta;
        }

        private int buscarIndice() {

            int index = -1;
            int contador = 0;

            for (; contador < this._CantMaximaColores; contador++) {

                if (this._Colores.GetValue(contador) == null) {

                    index = contador;
                    break;

                }

            }

            return index;

        }

        private int buscarIndice(Tempera tempera) {

            int index = -1;
            int contador = 0;

            for (; contador < this._CantMaximaColores; contador++) {

                if (this._Colores.GetValue(contador) != null) {

                    if (this._Colores[contador] == tempera) {

                        index = contador;
                        break;

                    }

                }

            }

            return index;

        }

    }

}
