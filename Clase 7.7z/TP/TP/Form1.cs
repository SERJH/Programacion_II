﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.TP1;

namespace TP {

    public partial class Form1 : Form {

        Numero numero1;
        Numero numero2;

        public Form1() {

            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e) {



        }

        private void txtNumero1_TextChanged(object sender, EventArgs e) {

            

        }

        private void btnOperar_Click(object sender, EventArgs e) {

            Calculadora calcu = new Calculadora();
            numero1 = new Numero(txtNumero1.Text);
            numero2 = new Numero(txtNumero2.Text);
            calcu.operar(numero1, numero2, cmbOperacion.Text);
            


        }
    }
}
