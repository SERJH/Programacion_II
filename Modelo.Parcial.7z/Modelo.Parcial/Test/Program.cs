﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelo.Parcial;

namespace Test {

    class Program {

        static void Main(string[] args) {

            Vehiculo v1 = new Vehiculo("HRH 444", EMarcas.Iveco, 8);
            Vehiculo v2 = new Vehiculo("HWZ 777", EMarcas.Scania, 6);

            Auto auto1 = new Auto("AAA 123", EMarcas.Ford, 4);
            Auto auto2 = new Auto("HHH 353", EMarcas.Honda, 5);

            Camion camion1 = new Camion(v1, 4000);
            Camion camion2 = new Camion(v2, 3000);

            Moto moto1 = new Moto("GB 557", EMarcas.Zanella, 2);
            Moto moto2 = new Moto("AS 112", EMarcas.Honda, 150, 2);

            Lavadero lavadero = new Lavadero(100, 250, 50, "Rapilav");

            lavadero += moto1;
            lavadero += moto2;
            lavadero += auto1;
            lavadero += auto2;
            lavadero += camion1;
            lavadero += camion2;

            Console.WriteLine(lavadero.getLavadero);

            Console.WriteLine("Total facturado: {0}", lavadero.MostrarTotalFacturado());
            Console.WriteLine("Total facturado autos: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Auto));
            Console.WriteLine("Total facturado camiones: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Camion));
            Console.WriteLine("Total facturado motos: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Moto));

            lavadero -= auto2;
            lavadero -= camion2;
            lavadero -= moto2;

            Console.WriteLine(lavadero.getLavadero);

            Console.WriteLine("Total facturado: {0}", lavadero.MostrarTotalFacturado());
            Console.WriteLine("Total facturado autos: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Auto));
            Console.WriteLine("Total facturado camiones: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Camion));
            Console.WriteLine("Total facturado motos: {0}", lavadero.MostrarTotalFacturado(EVehiculos.Moto));

            lavadero.getLista.Sort(Lavadero.OrdenarVehiculosPorPatente);

            Console.WriteLine("Ordenados por patente:");
            Console.WriteLine(lavadero.getLavadero);

            lavadero.getLista.Sort(Lavadero.OrdenarVehiculosPorMarca);

            Console.WriteLine("Ordenados por marca:");
            Console.WriteLine(lavadero.getLavadero);

            Console.Read();

        }

    }

}
