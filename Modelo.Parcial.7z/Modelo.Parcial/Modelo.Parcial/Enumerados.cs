﻿public enum EMarcas {
    
    Honda,
    Ford,
    Zanella,
    Scania,
    Iveco,
    Fiat

}

public enum EVehiculos {
    
    Auto,
    Camion,
    Moto

}