﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Parcial {

    public class Auto : Vehiculo {

        protected int _cantidadAsientos;

        public Auto(string patente, EMarcas marca, byte cantRuedas) : base(patente, marca, cantRuedas) { 
        
        }

        public Auto(string patente, EMarcas marca, int cantAsientos) : base(patente, marca, 4) {

            this._cantidadAsientos = cantAsientos;

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("Cantidad de asientos: ");
            sb.AppendLine(this._cantidadAsientos.ToString());

            return base.ToString() + sb.ToString();

        }

    }

}
