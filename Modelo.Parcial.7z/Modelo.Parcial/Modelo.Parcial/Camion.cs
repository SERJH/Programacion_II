﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Parcial {

    public class Camion : Vehiculo {

        protected float _tara;

        public Camion(string patente, EMarcas marca, byte cantRuedas) : base(patente, marca, cantRuedas) { 
        
        }

        public Camion(Vehiculo vehiculo, float tara) : this(vehiculo.getPatente, vehiculo.getMarca, vehiculo.getRuedas) {

            this._tara = tara;

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("Tara: ");
            sb.AppendLine(this._tara.ToString());

            return base.ToString() + sb.ToString();

        }

    }

}
