﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Parcial {

    public class Vehiculo {

        protected string _patente;
        protected byte _cantRuedas;
        protected EMarcas _marca;

        public Vehiculo(string patente, EMarcas marca, byte cantRuedas) {

            this._patente = patente;
            this._marca = marca;
            this._cantRuedas = cantRuedas;

        }

        public string getPatente {

            get {

                return this._patente;

            }

        }

        public EMarcas getMarca {

            get {

                return this._marca;

            }

        }

        public byte getRuedas {

            get {

                return this._cantRuedas;

            }

        }

        private string Mostrar() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nPatente: ");
            sb.AppendLine(this._patente);
            sb.Append("Marca: ");
            sb.AppendLine(this._marca.ToString());
            sb.Append("Cantidad de ruedas: ");
            sb.AppendLine(this._cantRuedas.ToString());

            return sb.ToString();

        }

        public override string ToString() {

            return this.Mostrar();

        }

        public static bool operator == (Vehiculo vehiculoUno, Vehiculo vehiculoDos) {

            bool retorno = false;

            if (vehiculoUno._patente == vehiculoDos._patente && vehiculoUno._marca == vehiculoDos._marca) {

                retorno = true;

            }

            return retorno;

        }

        public static bool operator !=(Vehiculo vehiculoUno, Vehiculo vehiculoDos) {

            return !(vehiculoUno == vehiculoDos);

        }

    }

}
