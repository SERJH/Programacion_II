﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Parcial {

    public class Lavadero {

        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        private Lavadero() {

            _vehiculos = new List<Vehiculo>();

        }

        public Lavadero(float precioAuto, float precioCamion, float precioMoto, string razonSocial):this() {

            Lavadero._precioAuto = precioAuto;
            Lavadero._precioCamion = precioCamion;
            Lavadero._precioMoto = precioMoto;
            this._razonSocial = razonSocial;

        }

        static Lavadero() {

            Random r = new Random();
            Lavadero._precioAuto = r.Next(150, 565);
            Lavadero._precioCamion = r.Next(150, 565);

            while (Lavadero._precioAuto == Lavadero._precioCamion) {

                Lavadero._precioCamion = r.Next(150, 565);

            }

            Lavadero._precioMoto = r.Next(150, 565);

            while (Lavadero._precioMoto == Lavadero._precioAuto || Lavadero._precioMoto == Lavadero._precioCamion) {

                Lavadero._precioMoto = r.Next(150, 565);

            }

        }

        public string getLavadero {

            get {

                StringBuilder sb = new StringBuilder();

                sb.Append("\nRazon social: ");
                sb.AppendLine(this._razonSocial.ToString());
                sb.Append("Precio auto: ");
                sb.AppendLine(Lavadero._precioAuto.ToString());
                sb.Append("Precio camion: ");
                sb.AppendLine(Lavadero._precioCamion.ToString());
                sb.Append("Precio moto: ");
                sb.AppendLine(Lavadero._precioMoto.ToString());
                sb.AppendLine(this.getVehiculos);

                return sb.ToString();

            }

        }

        public string getVehiculos {

            get {

                StringBuilder sb = new StringBuilder();

                sb.AppendLine("\nListado de vehiculos:");

                foreach (Vehiculo i in this._vehiculos) {

                    sb.Append(i.ToString());

                }

                return sb.ToString();

            }

        }

        public List<Vehiculo> getLista {

            get {

                return this._vehiculos;

            }

        }

        public double MostrarTotalFacturado() {

            double totalFacturado = 0;

            foreach (Vehiculo i in this._vehiculos) {

                if (i is Auto) {

                    totalFacturado += Lavadero._precioAuto;

                }
                else if (i is Camion) {

                    totalFacturado += Lavadero._precioCamion;

                } else {

                    totalFacturado += Lavadero._precioMoto;

                }

            }

            return totalFacturado;

        }

        public double MostrarTotalFacturado(EVehiculos vehiculo) {

            double totalFacturado = 0;

            switch (vehiculo) {

                case EVehiculos.Auto:

                    foreach (Vehiculo i in this._vehiculos) {

                        if (i is Auto) {

                            totalFacturado += Lavadero._precioAuto;

                        }

                    }

                    break;

                case EVehiculos.Camion:

                    foreach (Vehiculo i in this._vehiculos) {

                        if (i is Camion) {

                            totalFacturado += Lavadero._precioCamion;

                        }

                    }

                    break;

                case EVehiculos.Moto:

                    foreach (Vehiculo i in this._vehiculos) {

                        if (i is Moto) {

                            totalFacturado += Lavadero._precioMoto;

                        }

                    }

                    break;
            }

            return totalFacturado;

        }

        public static bool operator ==(Lavadero lavadero, Vehiculo vehiculo) {

            bool retorno = false;

            foreach (Vehiculo i in lavadero._vehiculos) {

                if (i == vehiculo) {

                    retorno = true;

                }

            }

            return retorno;

        }

        public static int operator ==(Vehiculo vehiculo, Lavadero lavadero) {

            int indice = 0;

            if (lavadero != vehiculo) {

                return -1;

            }

            foreach (Vehiculo i in lavadero._vehiculos) {

                if (i == vehiculo) {

                    break;

                }

                indice++;

            }

            return indice;

        }

        public static int operator !=(Vehiculo vehiculo, Lavadero lavadero) {

            return -1;

        }

        public static bool operator !=(Lavadero lavadero, Vehiculo vehiculo) {

            return !(lavadero == vehiculo);

        }

        public static Lavadero operator +(Lavadero lavadero, Vehiculo vehiculo) {

            Lavadero auxLavadero = lavadero;

            if (auxLavadero != vehiculo) {

                auxLavadero._vehiculos.Add(vehiculo);

            }

            return auxLavadero;

        }

        public static Lavadero operator -(Lavadero lavadero, Vehiculo vehiculo) {

            Lavadero auxLavadero = lavadero;

            int index;

            index = (vehiculo == lavadero);

            if (index != -1) {

                auxLavadero._vehiculos.RemoveAt(index);

            }

            return auxLavadero;

        }

        public static int OrdenarVehiculosPorPatente(Vehiculo vehiculoUno, Vehiculo vehiculoDos) { 

            return string.Compare(vehiculoUno.getPatente, vehiculoDos.getPatente);

        }

        public static int OrdenarVehiculosPorMarca(Vehiculo vehiculoUno, Vehiculo vehiculoDos) {

            return string.Compare(vehiculoUno.getMarca.ToString(), vehiculoDos.getMarca.ToString());

        }

    }

}
