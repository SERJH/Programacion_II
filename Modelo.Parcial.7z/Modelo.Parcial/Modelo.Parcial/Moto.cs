﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Parcial {

    public class Moto : Vehiculo {

        protected float _cilindrada;

        public Moto(string patente, EMarcas marca, byte cantRuedas) : base(patente, marca, cantRuedas) { 
        
        }

        public Moto(string patente, EMarcas marca, float cilindrada, byte cantRuedas) : this(patente, marca, cantRuedas) {

            this._cilindrada = cilindrada;

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append("Cilindrada: ");
            sb.AppendLine(this._cilindrada.ToString());

            return base.ToString() + sb.ToString();

        }

    }

}
