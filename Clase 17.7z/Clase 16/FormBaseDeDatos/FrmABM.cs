﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormBaseDeDatos {

    public partial class FrmABM : Form {

        private Persona _persona;

        public Persona PersonaDelForm {

            get { return this._persona; }
            
        }

        public FrmABM() {

            InitializeComponent();

        }

        private void btnAceptar_Click(object sender, EventArgs e) {

            this._persona = new Persona(0, txtNombre.Text, txtApellido.Text, int.Parse(txtEdad.Text));

        }

    }
}
