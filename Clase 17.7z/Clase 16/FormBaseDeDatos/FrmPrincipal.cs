﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormBaseDeDatos {

    public partial class FrmPrincipal : Form {

        private List<Persona> lista;
        private ProvedorDeDatos prov;
        private DataTable dTable;

        public FrmPrincipal() {
    
            InitializeComponent();

            prov = new ProvedorDeDatos();
            this.lista = new List<Persona>();
            this.dTable = new DataTable();

        }

        private void FrmPrincipal_Load(object sender, EventArgs e) {

            Actualizar();

        }

        private void btnAgregar_Click(object sender, EventArgs e) {

            FrmABM abmAgregar = new FrmABM();
            DialogResult d = abmAgregar.ShowDialog();

            if (d == DialogResult.OK) {

                ProvedorDeDatos.AgregarPersonaBD(abmAgregar.PersonaDelForm);
                Actualizar();

            }

        }

        private void btnModificar_Click(object sender, EventArgs e) {

            Persona p = lista[lstPersonas.SelectedIndex];

            FrmABM abmModificar = new FrmABM();

            DialogResult d = abmModificar.ShowDialog();

            if (d == DialogResult.OK) {

                Persona p2 = abmModificar.PersonaDelForm;
                p2.id = p.id;

                ProvedorDeDatos.ModificarPersonaBD(p2);
                Actualizar();

            }

        }

        private void btnQuitar_Click(object sender, EventArgs e) {

            Persona p = lista[lstPersonas.SelectedIndex];

            ProvedorDeDatos.EliminarPersonaBD(p);

            lstPersonas.Items.RemoveAt(lstPersonas.SelectedIndex);

            Actualizar();

        }

        private void Actualizar() {

            lstPersonas.Items.Clear();

            this.dTable = ProvedorDeDatos.ObtenerPersonaBD(true);
            //this.lista = ProvedorDeDatos.ObtenerPersonaBD();

            dgvLista.DataSource = dTable;

            //foreach (Persona i in lista) {

            //    lstPersonas.Items.Add(i.ToString());

            //}

            //lstPersonas.SelectedIndex = 0;

            
            dgvLista.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void btnBackup_Click(object sender, EventArgs e) {

            //Serializacion
            dTable.WriteXmlSchema("Esquema.xml");
            dTable.WriteXml("Datos.xml");

            //Deserializacion
            //ReadXmlSchema
            //ReadXml

        }


        //private void lstPersonas_SelectedIndexChanged(object sender, EventArgs e) {

        //    KeyEventArgs k = new KeyEventArgs(Keys.Delete);

        //    if (k.KeyCode == Keys.Delete) {

        //        Persona p = lista[lstPersonas.SelectedIndex];

        //        ProvedorDeDatos.EliminarPersonaBD(p);

        //        lstPersonas.Items.RemoveAt(lstPersonas.SelectedIndex);

        //        Actualizar();

        //    }

        //}

    }

}
