﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using Entidades;

namespace Consola {

    class Program {

        static void Main(string[] args) {

            ProvedorDeDatos pdd = new ProvedorDeDatos();

            /*List<Persona> lista = ProvedorDeDatos.ObtenerPersonaBD();

            foreach (Persona i in lista) {

                Console.WriteLine(i.ToString());

	        }

            Persona p1 = ProvedorDeDatos.ObtenerPersonaPorBD(1);

            Console.WriteLine(p1.ToString());

            Persona p2 = ProvedorDeDatos.ObtenerPersonaPorBD(7);

            if (p2 != null) {

                Console.WriteLine(p2.ToString());

            }

            Persona p = new Persona(7, "Santiago", "Moran", 21);

            ProvedorDeDatos.AgregarPersonaBD(p);

            Console.WriteLine("\nLista2 agregando:\n");

            List<Persona> lista2 = ProvedorDeDatos.ObtenerPersonaBD();

            foreach (Persona i in lista2) {

                Console.WriteLine(i.ToString());

            }

            ProvedorDeDatos.EliminarPersonaBD(p);

            Console.WriteLine("\nLista2 quitando:\n");

            lista2 = ProvedorDeDatos.ObtenerPersonaBD();

            foreach (Persona i in lista2) {

                Console.WriteLine(i.ToString());

            }
*/
            
            //ProvedorDeDatos.ModificarPersonaBD(new Persona(10, "xDgfwgawga", "xdd", 3));
            DataTable dTable = ProvedorDeDatos.ObtenerPersonaBD(true);

            Console.WriteLine("\nLista2 modifican2:\n");

            //lista2 = ProvedorDeDatos.ObtenerPersonaBD();

            //foreach (Persona i in lista2) {

            //    Console.WriteLine(i.ToString());

            //}


            Console.Read();

        }

    }

}
