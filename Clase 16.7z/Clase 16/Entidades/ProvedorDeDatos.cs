﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Entidades {

    public class ProvedorDeDatos {

        static SqlConnection conexion;
        static SqlCommand sqlCom;

        public ProvedorDeDatos() {
        
            conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            /*try {

                coneccion.Open();
                Console.WriteLine("Conexión lograda");
                

            }

            catch (Exception e) {

                Console.WriteLine(e.Message);
            
            }*/
        }

        public static List<Persona> ObtenerPersonaHC() {

            List<Persona> lista = new List<Persona>();

            lista.Add(new Persona(22345466, "Josias", "Rivola", 35));
            lista.Add(new Persona(35665332, "Ezequiel", "Mahafud", 28));
            lista.Add(new Persona(32666999, "Micaela", "Saez", 30));
            lista.Add(new Persona(50333222, "Marcos", "Rey", 13));

            return lista;

        }

        public static List<Persona> ObtenerPersonaBD() {

            List<Persona> lista = new List<Persona>();

            SqlDataReader sqlRead;

            sqlCom = new SqlCommand();

            sqlCom.Connection = conexion;

            sqlCom.CommandType = CommandType.Text;

            sqlCom.CommandText = "SELECT id,nombre,apellido,edad FROM Personas";

            conexion.Open();

            sqlRead = sqlCom.ExecuteReader();

            while (sqlRead.Read()) {

                lista.Add(new Persona((int)sqlRead[0], (string)sqlRead[1], (string)sqlRead[2], (int)sqlRead[3]));

            }

            sqlRead.Close();
            conexion.Close();

            return lista;

        }

        public static Persona ObtenerPersonaPorID(int id) {

            List<Persona> lista = ObtenerPersonaHC();
            Persona p = null;

            foreach (Persona i in lista) {

                if (i.id == id) {

                    p = i;
                    break;

                }

            }

            return p;

        }

        public static Persona ObtenerPersonaPorBD(int id) {

            List<Persona> lista = new List<Persona>();

            Persona p = null;

            SqlDataReader sqlRead;

            sqlCom = new SqlCommand();

            sqlCom.Connection = conexion;

            sqlCom.CommandType = CommandType.Text;

            sqlCom.CommandText = "SELECT id,nombre,apellido,edad FROM Personas WHERE id="+id.ToString();

            conexion.Open();

            sqlRead = sqlCom.ExecuteReader();

            if (sqlRead.HasRows) {

                sqlRead.Read();
                p = new Persona((int)sqlRead[0], (string)sqlRead[1], (string)sqlRead[2], (int)sqlRead[3]);

            }

            sqlRead.Close();
            conexion.Close();

            return p;

        }

        public static bool AgregarPersonaBD(Persona p) {

            List<Persona> lista = ProvedorDeDatos.ObtenerPersonaBD();

            SqlDataReader sqlRead;

            sqlCom = new SqlCommand();

            try {

                sqlCom.Connection = conexion;

                sqlCom.CommandType = CommandType.Text;

                sqlCom.CommandText = "INSERT INTO Personas (nombre,apellido,edad) VALUES ('" + p.nombre + "','" + p.apellido + "'," + p.edad + ")";

                conexion.Open();

                sqlCom.ExecuteNonQuery();
                conexion.Close();

                return true;

            } catch (Exception) {

                return false;

            } 

        }

        public static bool AgregarPersona(Persona p) {

            List<Persona> lista = ObtenerPersonaHC();

            try {

                lista.Add(p);

                return true;

            }
            catch (Exception) {

                return false;

            }

        }

        public static bool ModificarPersona(Persona p) {

            List<Persona> lista = ObtenerPersonaHC();
            int index;
            bool retorno = false;

            index = lista.IndexOf(p);

            if (index != null) {

                lista[index] = new Persona(39590490, "Santiago", "Moran", 21);

                retorno = true;

            } 

            return retorno;

        }

        public static bool EliminarPersonaBD(Persona p) {

            List<Persona> lista = ProvedorDeDatos.ObtenerPersonaBD();

            SqlDataReader sqlRead;

            sqlCom = new SqlCommand();

            try {

                sqlCom.Connection = conexion;

                sqlCom.CommandType = CommandType.Text;

                sqlCom.CommandText = "DELETE FROM Personas WHERE id="+p.id;

                conexion.Open();

                sqlCom.ExecuteNonQuery();

                conexion.Close();

                return true;

            }

            catch (Exception) {

                return false;

            } 

        }

        public static bool EliminarPersona(Persona p) {

            List<Persona> lista = ObtenerPersonaHC();
            int index;
            bool retorno = false;

            index = lista.IndexOf(p);

            if (index != null) {

                lista.RemoveAt(index);
                retorno = true;

            }

            return retorno;

        }

    }

}
