﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1 {

    class Program {

        static void Main(string[] args) {

            /*DateTime fecha = new DateTime(2020, 2, 2);
            Cosa obj = new Cosa(5, "fafa", fecha);
            obj.EstablecerValor(ConsoleColor.Cyan);
            /*obj.EstablecerValor(277);
            obj.EstablecerValor("xd");
            obj.EstablecerValor(DateTime.Now);
            Console.Write(obj.Mostrar());

            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\nDDD");*/

            int num;
            string dato;

            Console.Write("Ingrese un numero: ");
            dato = Console.ReadLine();
            while (!int.TryParse(dato, out num)) {

                Console.Write("Entrada invalida. Reingrese: ");
                dato = Console.ReadLine();
            }

            Console.Read();

            num = Math.Pow(num, 3);

            Console.WriteLine("El cubo de {0} es {1}", num, num);
        }

    }


}
