﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1 {

    enum eSemana { 
    
        Domingo, Lunes, Martes, Miercoles, Jueves, Viernes, Sabado

    }

    enum MyEnum {
        
    }

    class Cosa {

        public int entero;
        public string cadena;
        public DateTime fecha;
        ConsoleColor color;

        /// <summary>
        /// Establece un valor al entero
        /// </summary>
        /// <param name="entero">Es un entero</param>

        public void EstablecerValor(int entero) {

            this.entero = entero;

        }

        /// <summary>
        /// Establece un valor a la cadena
        /// </summary>
        /// <param name="cadena">Es un string</param>

        public void EstablecerValor(string cadena) {

            this.cadena = cadena;

        }

        /// <summary>
        /// Establece un valor a la fecha
        /// </summary>
        /// <param name="fecha">Es un objeto DateTime</param>

        public void EstablecerValor(DateTime fecha) {

            this.fecha = fecha;

        }

        public void EstablecerValor(ConsoleColor color) {

            this.color = color;

        }

        /// <summary>
        /// Muestra el valor de las tres variables
        /// </summary>
        /// <returns>Devuelve una string</returns>

        public string Mostrar() {

            Console.ForegroundColor = this.color;
            Console.BackgroundColor = ConsoleColor.Magenta;

            return "El valor del entero es " 
                    + this.entero + "\nEl valor de la cadena es " 
                    + this.cadena + "\nEl valor de la fecha es " 
                    + this.fecha.Day + "/" 
                    + this.fecha.Month + "/" 
                    + this.fecha.Year;

        }

        /// <summary>
        /// Inicializa las 3 variables con valores por defecto
        /// </summary>

        public Cosa() {

            EstablecerValor(0);
            EstablecerValor("");
            EstablecerValor(DateTime.Now);

        }

        /// <summary>
        /// Inicializa el entero con un valor, las demas por defecto
        /// </summary>
        /// <param name="entero">Es un entero</param>

        public Cosa(int entero):this() {

            EstablecerValor(entero);

        }

        /// <summary>
        /// Inicializa el entero y la cadena con un valor, la fecha por defecto
        /// </summary>
        /// <param name="entero">Es un entero</param>
        /// <param name="cadena">Es una string</param>

        public Cosa(int entero, string cadena):this(entero) {

            EstablecerValor(cadena);

        }

        /// <summary>
        /// Inicializa los tres atributos
        /// </summary>
        /// <param name="entero">Es un entero</param>
        /// <param name="cadena">Es un string</param>
        /// <param name="fecha">Es un DateTime</param>

        public Cosa(int entero, string cadena, DateTime fecha) : this(entero, cadena) {

            EstablecerValor(fecha);

        }

    }

}
