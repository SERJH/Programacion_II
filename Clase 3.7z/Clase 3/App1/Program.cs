﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1 {

    class Program {

        static void Main(string[] args) {

            Auto a1 = new Auto();
            Auto a2 = new Auto();

            a1.marca = "Fiat";
            a2.marca = "Ford";

            a1.patente = "A001";
            a2.patente = "B002";

            a1.precio = 30000;
            a2.precio = 80000;

            Console.WriteLine(Auto.Mostrar(a1));
            Console.WriteLine(Auto.Mostrar(a2));

            TimeSpan difTiempo =  Auto.f_Ultimo - Auto.f_Inicio;

            

            Console.WriteLine("Primero creado: {0}:{1}:{2}:{3}", Auto.f_Inicio.Hour, Auto.f_Inicio.Minute, Auto.f_Inicio.Second, Auto.f_Inicio.Millisecond);
            Console.WriteLine("Ultimo creado: {0}:{1}:{2}:{3}", Auto.f_Ultimo.Hour, Auto.f_Ultimo.Minute, Auto.f_Ultimo.Second, Auto.f_Ultimo.Millisecond);
            Console.WriteLine("Diferencia de tiempo entre ambos: {0} milisegundos", difTiempo.TotalMilliseconds); 
            Console.Read();
        }

    }

}
