﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1 {

    class Auto {

        public string marca;
        public string patente;
        public float precio;
        public static int cantInstancias;
        public static DateTime f_Inicio;
        public static DateTime f_Ultimo;

        public Auto() {

            if (cantInstancias == 0) {

                Auto.f_Inicio = DateTime.Now; //Auto. por ser static

            }
            else {

                Auto.f_Ultimo = DateTime.Now;

            }

            Auto.cantInstancias++;

        }

        private string Mostrar() {

            return marca + " --- " + patente + " --- " + precio;

        }

        public static string Mostrar(Auto auto) {

            return auto.Mostrar();

        }

    }

}
