﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;

namespace Entidades {

    public class OtraClase : PersonaExterna {

        public OtraClase(string nombre, string apellido, int edad, Entidades.Externa.ESexo sexo) : base(nombre, apellido, edad, sexo) { 
        
        }

        public string ObtenerInfo() {

            StringBuilder sb = new StringBuilder();

            sb.Append(base._nombre);
            sb.Append(" --- ");
            sb.Append(base._apellido);
            sb.Append(" --- ");
            sb.Append(base._edad.ToString());
            sb.Append(" --- ");
            sb.Append(base._sexo.ToString());

            return sb.ToString();

        }

    }

}
