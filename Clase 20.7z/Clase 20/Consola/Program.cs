﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using Entidades.Externa;
using Entidades.Externa.Sellada;

namespace Consola {

    static class Program {

        static void Main(string[] args) {

            Persona p = new Persona("Juan", "Perez", "31", ESexo.Masculino);
            PersonaExterna pe = new OtraClase("Santiago", "Moran", 21, Entidades.Externa.ESexo.Masculino);
            OtraClase po = new OtraClase("Yaki", "Sieras", 21, Entidades.Externa.ESexo.Femenino);
            PersonaExternaSellada pes = new PersonaExternaSellada("Johnny", "Bola", 17, Entidades.Externa.Sellada.ESexo.Masculino);
            string hola = "chau";

            //Console.WriteLine("Nombre: {0}\nApellido: {1}\nEdad: {2}\nSexo: {3}", p.Nombre, p.Apellido, p.Edad, p.Sexo);
            //Console.Read();
            //Console.WriteLine("Nombre: {0}\nApellido: {1}\nEdad: {2}\nSexo: {3}", pes.Nombre, pes.Apellido, pes.Edad, pes.Sexo);
            
            //Console.WriteLine(pes.ObtenerInfo());
            //Console.WriteLine(po.ObtenerInfo());
            Console.WriteLine(pes.ObtenerInfo(true));
            Console.WriteLine(pes.ObtenerInfo(false));
            //Console.WriteLine(hola.CantidadDeCaracteres());
            Console.ReadKey();

        }

        static string ObtenerInfo(this PersonaExternaSellada persona) { 
        

            StringBuilder sb = new StringBuilder();

            sb.Append(persona.Nombre);
            sb.Append(" --- ");
            sb.Append(persona.Apellido);
            sb.Append(" --- ");
            sb.Append(persona.Edad.ToString());
            sb.Append(" --- ");
            sb.Append(persona.Sexo.ToString());

            return sb.ToString();

        }

        static string ObtenerInfo(this PersonaExternaSellada persona, bool mayus) {


            StringBuilder sb = new StringBuilder();
            string retorno;

            sb.Append(persona.Nombre);
            sb.Append(" --- ");
            sb.Append(persona.Apellido);
            sb.Append(" --- ");
            sb.Append(persona.Edad.ToString());
            sb.Append(" --- ");
            sb.Append(persona.Sexo.ToString());

            if (mayus) 
                retorno = sb.ToString().ToUpper();
            else 
                retorno = sb.ToString().ToLower();

            return retorno;

        }

        static int CantidadDeCaracteres(this string cadena) {

            return cadena.Length;

        }

    }

}
