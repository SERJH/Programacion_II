﻿namespace FormCalculadora {
    partial class CalculadoraForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnSiete = new System.Windows.Forms.Button();
            this.btnNueve = new System.Windows.Forms.Button();
            this.btnOcho = new System.Windows.Forms.Button();
            this.btnCuatro = new System.Windows.Forms.Button();
            this.btnCinco = new System.Windows.Forms.Button();
            this.btnSeis = new System.Windows.Forms.Button();
            this.btnUno = new System.Windows.Forms.Button();
            this.btnDos = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnSumar = new System.Windows.Forms.Button();
            this.btnRestar = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnTres = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnCero = new System.Windows.Forms.Button();
            this.panelNumeros = new System.Windows.Forms.Panel();
            this.panelNumeros.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(8, 12);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(130, 20);
            this.txtResultado.TabIndex = 0;
            // 
            // btnSiete
            // 
            this.btnSiete.Location = new System.Drawing.Point(9, 3);
            this.btnSiete.Name = "btnSiete";
            this.btnSiete.Size = new System.Drawing.Size(40, 23);
            this.btnSiete.TabIndex = 1;
            this.btnSiete.Text = "7";
            this.btnSiete.UseVisualStyleBackColor = true;
            // 
            // btnNueve
            // 
            this.btnNueve.Location = new System.Drawing.Point(99, 3);
            this.btnNueve.Name = "btnNueve";
            this.btnNueve.Size = new System.Drawing.Size(40, 23);
            this.btnNueve.TabIndex = 2;
            this.btnNueve.Text = "9";
            this.btnNueve.UseVisualStyleBackColor = true;
            // 
            // btnOcho
            // 
            this.btnOcho.Location = new System.Drawing.Point(53, 3);
            this.btnOcho.Name = "btnOcho";
            this.btnOcho.Size = new System.Drawing.Size(40, 23);
            this.btnOcho.TabIndex = 3;
            this.btnOcho.Text = "8";
            this.btnOcho.UseVisualStyleBackColor = true;
            // 
            // btnCuatro
            // 
            this.btnCuatro.Location = new System.Drawing.Point(9, 32);
            this.btnCuatro.Name = "btnCuatro";
            this.btnCuatro.Size = new System.Drawing.Size(40, 23);
            this.btnCuatro.TabIndex = 4;
            this.btnCuatro.Text = "4";
            this.btnCuatro.UseVisualStyleBackColor = true;
            // 
            // btnCinco
            // 
            this.btnCinco.Location = new System.Drawing.Point(53, 32);
            this.btnCinco.Name = "btnCinco";
            this.btnCinco.Size = new System.Drawing.Size(40, 23);
            this.btnCinco.TabIndex = 5;
            this.btnCinco.Text = "5";
            this.btnCinco.UseVisualStyleBackColor = true;
            // 
            // btnSeis
            // 
            this.btnSeis.Location = new System.Drawing.Point(99, 32);
            this.btnSeis.Name = "btnSeis";
            this.btnSeis.Size = new System.Drawing.Size(40, 23);
            this.btnSeis.TabIndex = 6;
            this.btnSeis.Text = "6";
            this.btnSeis.UseVisualStyleBackColor = true;
            // 
            // btnUno
            // 
            this.btnUno.Location = new System.Drawing.Point(9, 61);
            this.btnUno.Name = "btnUno";
            this.btnUno.Size = new System.Drawing.Size(40, 23);
            this.btnUno.TabIndex = 7;
            this.btnUno.Text = "1";
            this.btnUno.UseVisualStyleBackColor = true;
            // 
            // btnDos
            // 
            this.btnDos.Location = new System.Drawing.Point(53, 61);
            this.btnDos.Name = "btnDos";
            this.btnDos.Size = new System.Drawing.Size(40, 23);
            this.btnDos.TabIndex = 8;
            this.btnDos.Text = "2";
            this.btnDos.UseVisualStyleBackColor = true;
            // 
            // btnIgual
            // 
            this.btnIgual.Location = new System.Drawing.Point(8, 164);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(130, 23);
            this.btnIgual.TabIndex = 9;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = true;
            // 
            // btnSumar
            // 
            this.btnSumar.Location = new System.Drawing.Point(149, 45);
            this.btnSumar.Name = "btnSumar";
            this.btnSumar.Size = new System.Drawing.Size(40, 23);
            this.btnSumar.TabIndex = 10;
            this.btnSumar.Text = "+";
            this.btnSumar.UseVisualStyleBackColor = true;
            // 
            // btnRestar
            // 
            this.btnRestar.Location = new System.Drawing.Point(148, 74);
            this.btnRestar.Name = "btnRestar";
            this.btnRestar.Size = new System.Drawing.Size(40, 23);
            this.btnRestar.TabIndex = 11;
            this.btnRestar.Text = "-";
            this.btnRestar.UseVisualStyleBackColor = true;
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Location = new System.Drawing.Point(148, 103);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(40, 23);
            this.btnMultiplicar.TabIndex = 12;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            // 
            // btnDividir
            // 
            this.btnDividir.Location = new System.Drawing.Point(148, 132);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(40, 23);
            this.btnDividir.TabIndex = 13;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            // 
            // btnTres
            // 
            this.btnTres.Location = new System.Drawing.Point(99, 61);
            this.btnTres.Name = "btnTres";
            this.btnTres.Size = new System.Drawing.Size(40, 23);
            this.btnTres.TabIndex = 14;
            this.btnTres.Text = "3";
            this.btnTres.UseVisualStyleBackColor = true;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(8, 132);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(60, 23);
            this.btnLimpiar.TabIndex = 15;
            this.btnLimpiar.Text = "C";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // btnCero
            // 
            this.btnCero.Location = new System.Drawing.Point(78, 132);
            this.btnCero.Name = "btnCero";
            this.btnCero.Size = new System.Drawing.Size(60, 23);
            this.btnCero.TabIndex = 16;
            this.btnCero.Text = "0";
            this.btnCero.UseVisualStyleBackColor = true;
            // 
            // panelNumeros
            // 
            this.panelNumeros.Controls.Add(this.btnSiete);
            this.panelNumeros.Controls.Add(this.btnCuatro);
            this.panelNumeros.Controls.Add(this.btnOcho);
            this.panelNumeros.Controls.Add(this.btnNueve);
            this.panelNumeros.Controls.Add(this.btnTres);
            this.panelNumeros.Controls.Add(this.btnCinco);
            this.panelNumeros.Controls.Add(this.btnUno);
            this.panelNumeros.Controls.Add(this.btnDos);
            this.panelNumeros.Controls.Add(this.btnSeis);
            this.panelNumeros.Location = new System.Drawing.Point(-1, 42);
            this.panelNumeros.Name = "panelNumeros";
            this.panelNumeros.Size = new System.Drawing.Size(143, 89);
            this.panelNumeros.TabIndex = 17;
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(196, 195);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.panelNumeros);
            this.Controls.Add(this.btnCero);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnRestar);
            this.Controls.Add(this.btnSumar);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.txtResultado);
            this.Name = "Calculadora";
            this.Text = "Calculadora";
            this.panelNumeros.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnSiete;
        private System.Windows.Forms.Button btnNueve;
        private System.Windows.Forms.Button btnOcho;
        private System.Windows.Forms.Button btnCuatro;
        private System.Windows.Forms.Button btnCinco;
        private System.Windows.Forms.Button btnSeis;
        private System.Windows.Forms.Button btnUno;
        private System.Windows.Forms.Button btnDos;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Button btnRestar;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnTres;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnCero;
        private System.Windows.Forms.Panel panelNumeros;
    }
}