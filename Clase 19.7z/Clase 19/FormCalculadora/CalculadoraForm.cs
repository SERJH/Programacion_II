﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormCalculadora {

    public partial class CalculadoraForm : Form {

        DelOperacion delegado = new DelOperacion(Calculadora.Calcular);

        double numeroUno = 0;
        double numeroDos = 0;
        ECalculo operador;

        bool manejadorOperadoresAgregados = false;
        bool ultimoFueOperacion = false;
        bool primerNumero = true;

        public CalculadoraForm() {

            InitializeComponent();

            InicioManejadores();

        }
        
        private void ManejadorCentral(object sender, EventArgs e) {

            if (sender is Button) {

                switch (((Button)sender).Name) {

                    case "btnCero":
                    case "btnUno":
                    case "btnDos":
                    case "btnTres":
                    case "btnCuatro":
                    case "btnCinco":
                    case "btnSeis":
                    case "btnSiete":
                    case "btnOcho":
                    case "btnNueve":
                        CaseNumeros((Button)sender);
                        break;
                    case "btnLimpiar":
                        ReiniciarManejadores();
                        break;
                    case "btnIgual":
                        Calcular();
                        break;
                    case "btnSumar":
                    case "btnRestar":
                    case "btnMultiplicar":
                    case "btnDividir":
                        CaseOperadores((Button)sender);
                        break;

                }

            }

        }

        private void CaseNumeros(Button boton) {

            char op = ' ';

            if (primerNumero) {
                this.numeroUno = (10 * this.numeroUno) + double.Parse(boton.Text);
            } else {
                this.numeroDos = (10 * this.numeroDos) + double.Parse(boton.Text);
                this.btnLimpiar.Click += ManejadorCentral;
            }

            if (!manejadorOperadoresAgregados) {
                AgregarManejadorOperadores();
                manejadorOperadoresAgregados = true;
            }

            if (ultimoFueOperacion) {
                this.btnIgual.Click += ManejadorCentral;
            }

            switch (operador) {
                case ECalculo.Suma:
                    op = '+';
                    break;
                case ECalculo.Resta:
                    op = '-';
                    break;
                case ECalculo.Multiplicacion:
                    op = '*';
                    break;
                case ECalculo.Division:
                    op = '/';
                    break;
            }

            if (primerNumero) {

                txtResultado.Text = numeroUno.ToString();

            } else {

                txtResultado.Text = numeroUno.ToString() + " " + op + " " + numeroDos.ToString();
            
            }
            

        }

        private void CaseOperadores(Button boton) {

            switch (boton.Text) {
                case "+":
                    this.operador = ECalculo.Suma;
                    break;
                case "-":
                    this.operador = ECalculo.Resta;
                    break;
                case "*":
                    this.operador = ECalculo.Multiplicacion;
                    break;
                case "/":
                    this.operador = ECalculo.Division;
                    break;
            }

            this.txtResultado.Text = this.numeroUno.ToString() + " " + boton.Text;

            QuitarManejadorOperadores();
            ultimoFueOperacion = true;
            manejadorOperadoresAgregados = false;
            primerNumero = false;

        }

        private void QuitarManejadorOperadores() { 
        
            this.btnSumar.Click -= ManejadorCentral;
            this.btnRestar.Click -= ManejadorCentral;
            this.btnMultiplicar.Click -= ManejadorCentral;
            this.btnDividir.Click -= ManejadorCentral;
        
        }

        private void AgregarManejadorOperadores() { 
        
            this.btnSumar.Click += ManejadorCentral;
            this.btnRestar.Click += ManejadorCentral;
            this.btnMultiplicar.Click += ManejadorCentral;
            this.btnDividir.Click += ManejadorCentral;

        }

        private void ReiniciarManejadores() {

            foreach (Control i in this.Controls) {

                i.Click -= ManejadorCentral;

            }

            InicioManejadores();
            primerNumero = true;
            this.numeroUno = 0;
            this.numeroDos = 0;
            this.txtResultado.Text = " ";

        }

        private void InicioManejadores() {

            foreach (Button i in this.panelNumeros.Controls) {

                i.Click += ManejadorCentral;

            }

            this.btnCero.Click += ManejadorCentral;

        }

        private void Calcular() {

            double resultado = delegado(numeroUno, numeroDos, operador);
            txtResultado.Text = resultado.ToString();

        }

    }

}
