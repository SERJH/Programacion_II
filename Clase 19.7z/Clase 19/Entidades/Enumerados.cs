﻿public enum ECalculo {
    
    Suma,
    Resta,
    Multiplicacion,
    Division

}