﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public delegate double DelOperacion(double numUno, double numDos, ECalculo operador);

    public class Calculadora {

        private double _numUno;
        private double _numDos;
        private ECalculo _operador;

        public double NumeroUno {

            get { return this._numUno; }
            set { this._numUno = value; }
        
        }

        public double NumeroDos {

            get { return this._numDos; }
            set { this._numDos = value; }
        
        }

        public ECalculo Operador {

            get { return this._operador; }
            set { this._operador = value; }
        
        }

        public static double Calcular(double numeroUno, double numeroDos, ECalculo calculo) {

            double retorno = 0;

            switch (calculo) {

                case ECalculo.Suma:
                    retorno = numeroUno + numeroDos;
                    break;
                case ECalculo.Resta:
                    retorno = numeroUno - numeroDos;
                    break;
                case ECalculo.Multiplicacion:
                    retorno = numeroUno * numeroDos;
                    break;
                case ECalculo.Division:
                    retorno = numeroUno / numeroDos;
                    break;

            }

            return retorno;

        }

    }

}
