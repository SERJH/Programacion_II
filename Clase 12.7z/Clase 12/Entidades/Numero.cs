﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class Numero {

        protected int _numero;

        public int getNumero {

            get {

                return this._numero;

            }

        }

        public Numero(int numero) {

            this._numero = numero;

        }

        public static int operator +(Numero numUno, Numero numDos) {

            return numUno.getNumero + numDos.getNumero;

        }

        public static int operator -(Numero numUno, Numero numDos) {

            return numUno.getNumero - numDos.getNumero;

        }

        public static int operator *(Numero numUno, Numero numDos) {

            return numUno.getNumero * numDos.getNumero;

        }

        public static double operator /(Numero numUno, Numero numDos) {

            try {

                return numUno.getNumero / numDos.getNumero;

            }

            catch(DivideByZeroException e) {

                Console.WriteLine(e.Message);

            }

            return 0;

        }

    }

}
