﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class ColectoraDeNumeros {

        private List<Numero> numeros;

        public ETipoNumero Numeros {
            
            get; 
            set;
        
        }

        public int SumaNumeros {

            get {

                return (int)ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Suma);

            }

        }

        public int RestaNumeros {

            get {

                return (int)ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Resta);

            }

        }

        public int MultiplicacionNumeros {

            get {

                return (int)ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Multiplicacion);
            
            }

        }

        public double DivisionNumeros {

            get {

                return ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Division);

            }

        }

        private ColectoraDeNumeros() {

            numeros = new List<Numero>();

        }

        public ColectoraDeNumeros(ETipoNumero tipo):this() {

            this.Numeros = tipo;

        }

        static protected double ObtenerResultado(ColectoraDeNumeros colectora, ETipoResultado tipo) { 
        
            double retorno = colectora.numeros[0].getNumero;

            for (int i = 1; i < colectora.numeros.Count; i++) {

                switch (tipo) {
                    case ETipoResultado.Suma:
                        retorno += colectora.numeros[i].getNumero;
                        break;
                    case ETipoResultado.Resta:
                        retorno -= colectora.numeros[i].getNumero;
                        break;
                    case ETipoResultado.Multiplicacion:
                        retorno *= colectora.numeros[i].getNumero;
                        break;
                    case ETipoResultado.Division:
                        try {

                            retorno /= colectora.numeros[i].getNumero;

                        }
                        catch (DivideByZeroException e) {

                            Console.WriteLine(e.Message);

                        }
                        break;
                }

            }

            return retorno;

        }

        public static ColectoraDeNumeros operator +(ColectoraDeNumeros colectora, Numero num) {

            ColectoraDeNumeros auxColectora = colectora;

            if (Verificadora.VerificarNumero(num, colectora.Numeros)) {
                
                auxColectora.numeros.Add(num);

            }
            
            return auxColectora;

        }

        public static ColectoraDeNumeros operator -(ColectoraDeNumeros colectora, Numero num) {

            ColectoraDeNumeros auxColectora = colectora;

            auxColectora.numeros.Remove(num);

            return auxColectora;

        }

        public override string ToString() {

            StringBuilder sb = new StringBuilder();

            foreach (Numero i in this.numeros) {

                sb.AppendLine(i.getNumero.ToString());

            }

            return sb.ToString();

        }

    }

}
