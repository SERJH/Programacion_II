﻿public enum ETipoNumero {
    
    Par,
    Impar,
    Positivo,
    Negativo,
    Cero

}

public enum ETipoResultado {
    
    Suma,
    Resta,
    Multiplicacion,
    Division

}