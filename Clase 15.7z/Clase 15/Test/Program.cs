﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Test {

    class Program {

        static void Main(string[] args) {
        
            string linea = "";
            
            List<Persona> listaP = new List<Persona>();

            Alumno a1 = new Alumno(23, "Ahre", "Nose");
            Alumno a2 = new Alumno(44, "hhh", "jjj");
            Persona personaUno = new Persona("Santiago", "Moran");


            listaP.Add(a1);
            listaP.Add(a2);
            listaP.Add(personaUno);

            // Una carpeta en especifico para guardar
            //Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)

            /*using (StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory+@"\Personas.txt", true)) { 
            
                sw.WriteLine(personaUno.ToString());

            }*/

            

            XmlSerializer serializador = new XmlSerializer(typeof(List<Persona>));

            TextWriter tw = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Personas.xml");

            serializador.Serialize(tw, listaP);

            tw.Close();

            TextReader tr = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Personas.xml");

            List<Persona> p = (List<Persona>)serializador.Deserialize(tr);

            tr.Close();

            for (int i = 0; i < p.Count; i++) {

                Console.WriteLine(p[i].ToString());

            }

            /*using (StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\Personas.txt")) { 
            
                while (!sr.EndOfStream) {

                    linea = sr.ReadLine();
                    Console.WriteLine(linea);

                }

            }*/

            Console.Read();
        
        }

            

    }

}
