﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades {

    public class Alumno : Persona {

        private int _legajo;

        public int Legajo {

            get { return this._legajo; }
            set { this._legajo = value; }

        }

        public Alumno() : base("", "") { 
        
            this.Legajo = 0;

        }

        public Alumno(int legajo, string nombre, string apellido) : base(nombre, apellido) {

            this.Legajo = legajo;

        }

    }

}
