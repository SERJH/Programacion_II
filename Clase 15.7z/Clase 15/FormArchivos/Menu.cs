﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormArchivos {

    public partial class Menu : Form {

        Persona p;

        public Menu() {

            InitializeComponent();
            p = new Persona("Santiago", "Moran");

        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e) {

            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {

                string path = saveFileDialog1.FileName;

                using (StreamWriter sw = new StreamWriter(path, true)) {

                    sw.WriteLine(p.ToString());

                }

            }

            

        }

        private void leerToolStripMenuItem_Click(object sender, EventArgs e) {

            openFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            if (openFileDialog1.ShowDialog() == DialogResult.OK) {

                string path = openFileDialog1.FileName;

                using (StreamReader sr = new StreamReader(path)) {

                    while (!sr.EndOfStream) {

                        listBox1.Items.Add(sr.ReadLine());

                    }

                    MessageBox.Show(sr.ReadToEnd());

                }

            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) {



        }
    }
}
