﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Centralita {

    public class Centralita {

        private List<Llamada> _listaDeLlamadas;
        protected string _razonSocial;

        public float GananciaPorLocal {

            get {

                return this.CalcularGanancia(TipoLlamada.Local);

            }

        }

        public float GananciaPorProvincial {

            get {

                return this.CalcularGanancia(TipoLlamada.Provincial);

            }

        }

        public float GananciaTotal {

            get {

                return this.CalcularGanancia(TipoLlamada.Todas);

            }

        }

        public List<Llamada> Llamadas {

            get {

                return this._listaDeLlamadas;

            }

        }

        private float CalcularGanancia(TipoLlamada tipo) {

            float retorno = 0;
            Local llamadaLocal;
            Provincial llamadaProvincial;

            switch (tipo) {
                case TipoLlamada.Local:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Local) { 
                        
                        llamadaLocal = (Local)i;
                        retorno += (llamadaLocal.Duracion * llamadaLocal.CostoLlamada);

                        }           

                    }

                    break;

                case TipoLlamada.Provincial:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Provincial) {

                            llamadaProvincial = (Provincial)i;
                            retorno += (llamadaProvincial.Duracion * llamadaProvincial.CostoLlamada);

                        }

                    }

                    break;

                case TipoLlamada.Todas:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Local) {

                            llamadaLocal = (Local)i;
                            retorno += (llamadaLocal.Duracion * llamadaLocal.CostoLlamada);

                        } else {

                            llamadaProvincial = (Provincial)i;
                            retorno += (llamadaProvincial.Duracion * llamadaProvincial.CostoLlamada);

                        }

                    }

                    break;

            }

            return retorno;

        }

        public Centralita() {

            this._listaDeLlamadas = new List<Llamada>();

        }

        public Centralita(string nombreEmpresa):this() {

            this._razonSocial = nombreEmpresa;

        }

        public string Mostrar() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nRazon social: ");
            sb.AppendLine(this._razonSocial);
            sb.Append("Ganancia total: ");
            sb.AppendLine(this.GananciaTotal.ToString());
            sb.Append("Ganancias locales: ");
            sb.AppendLine(this.GananciaPorLocal.ToString());
            sb.Append("Ganancias provinciales: ");
            sb.AppendLine(this.GananciaPorProvincial.ToString());
            sb.AppendLine("Detalle de las llamadas realizadas: ");

            foreach (Llamada i in this._listaDeLlamadas) {

                sb.AppendLine(i.ToString());

            }

            return sb.ToString();

        }

        public void OrdenarLlamadas(ECriterio criterio) {

            int orden;
            int crit;
            Llamada aux;

            if (criterio == ECriterio.Ascendente)
                crit = 1;
            else
                crit = -1;

            for (int i = 0; i < (this._listaDeLlamadas.Count - 1); i++) {

                for (int j = i + 1; j <= (this._listaDeLlamadas.Count - 1); j++) {

                    orden = Llamada.OrdenarPorDuracion(this._listaDeLlamadas[i], this._listaDeLlamadas[j]); 

                    if (orden == crit) {
                    
                        aux = this._listaDeLlamadas[i];
                        this._listaDeLlamadas[i] = this._listaDeLlamadas[j];
                        this._listaDeLlamadas[j] = aux;

                    }

                }

            }

        }

        private void AgregarLlamada(Llamada llamada) {

            this._listaDeLlamadas.Add(llamada);

        }

        public static bool operator ==(Centralita centralita, Llamada llamada) {

            bool retorno = false;

            foreach (Llamada i in centralita._listaDeLlamadas) {

                if (i == llamada && i.Equals(llamada)) {

                    retorno = true;
                    break;

                }

            }

            return retorno;

        }

        public static bool operator !=(Centralita centralita, Llamada llamada) {

            return !(centralita == llamada);

        }

        public static Centralita operator +(Centralita centralita, Llamada llamada) {

            Centralita auxCentralita = centralita;

            if (auxCentralita != llamada)
                auxCentralita._listaDeLlamadas.Add(llamada);

            return auxCentralita;

        }

    }
}
