﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Centralita {

    public abstract class Llamada {

        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;

        #region PROPIEDADES

        public abstract float CostoLlamada {

            get;

        }

        public float Duracion {

            get {

                return this._duracion;

            }

        }

        public string NroDestino {

            get {

                return this._nroDestino;

            }

        }

        public string NroOrigen {

            get {

                return this._nroOrigen;

            }

        }

        #endregion PROPIEDADES

        #region CONSTRUCTORES

        public Llamada(string origen, string destino, float duracion) {

            this._nroOrigen = origen;
            this._nroDestino = destino;
            this._duracion = duracion;

        }

        #endregion CONSTRUCTORES

        #region METODOS

        protected virtual string Mostrar() { 
        
            return "Origen: " + this._nroOrigen +
                   " | Destino: " + this._nroDestino +
                   " | Duracion: " + this._duracion;

        }

        public static int OrdenarPorDuracion(Llamada llamadaUno, Llamada llamadaDos) {

            int retorno = 0;

            if (llamadaUno.Duracion > llamadaDos.Duracion) {

                retorno = 1;

            } else if (llamadaUno.Duracion < llamadaDos.Duracion) {

                retorno = -1;

            }

            return retorno;

        }

        #endregion METODOS

        #region OPERADORES

        public static bool operator ==(Llamada llamadaUno, Llamada llamadaDos) {

            bool retorno = false;

            if (llamadaUno._nroOrigen == llamadaDos._nroOrigen &&
                llamadaUno._nroDestino == llamadaDos._nroDestino &&
                llamadaUno.Equals(llamadaDos)) { 
            
                retorno = true;

            }
                
            return retorno;

        }

        public static bool operator !=(Llamada llamadaUno, Llamada llamadaDos) {

            return !(llamadaUno == llamadaDos);

        }

        #endregion OPERADORES

    }

}
