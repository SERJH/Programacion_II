﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entidades.Centralita;

namespace CentralitaWindowsForms {

    public partial class FrmProvincial : CentralitaWindowsForms.FrmLlamada {

        private Provincial provincial;

        public FrmProvincial() {

            InitializeComponent();

        }

        public override Llamada LlamadaProp {
            get {
                return this.provincial;
            }
        }

        protected override void btnAceptar_Click(object sender, EventArgs e) {

            float duracion;
            Franja franja;
           
            switch (cmbFranja.Text)
	        {
		        case "Franja 1":
                    franja = Franja.Franja_1;
                    break;
                case "Franja 2":
                    franja = Franja.Franja_2;
                    break;
                case "Franja 3":
                    franja = Franja.Franja_3;
                    break;
                default:
                    franja = Franja.Franja_1;
                    break;
	        }

            float.TryParse(txtDuracion.Text, out duracion);

            provincial = new Provincial(txtOrigen.Text,franja,duracion,txtDestino.Text);

            base.btnAceptar_Click(sender, e);

        }

    }

}
