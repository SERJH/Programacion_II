﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entidades.Centralita;

namespace CentralitaWindowsForms {

    public partial class FrmLocal : CentralitaWindowsForms.FrmLlamada {

        private Local local;

        public FrmLocal() {

            InitializeComponent();

        }

        public override Llamada LlamadaProp {
            get {
                return this.local;
            }
        }

        protected override void btnAceptar_Click(object sender, EventArgs e) {

            float costo;
            float duracion;

            float.TryParse(base.txtDuracion.Text, out duracion);
            float.TryParse(txtCosto.Text, out costo);

            this.local = new Local(base.txtOrigen.Text, duracion, base.txtDestino.Text, costo);

            base.btnAceptar_Click(sender,e);

        }


    }

}