﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Centralita;

namespace CentralitaWindowsForms
{
    public partial class FrmCentralita : Form
    {
        private Centralita centralita = new Centralita();
        private Local local;
        private Provincial provincial;
        private ECriterio criterio = ECriterio.Ascendente;

        public FrmCentralita()
        {
            InitializeComponent();
            cboOrdenamiento.Text = "Ascendente";
        }

        private void btnLocal_Click(object sender, EventArgs e) {

            DialogResult resultado;

            FrmLocal llamadaLocal = new FrmLocal();
            resultado = llamadaLocal.ShowDialog();

            if (resultado == DialogResult.OK) {

                centralita += llamadaLocal.LlamadaProp;
                lstVisor.Items.Add(DatosLlamada(llamadaLocal.LlamadaProp));

            }

        }

        private void btnProvincial_Click(object sender, EventArgs e) {

            DialogResult resultado;

            FrmProvincial llamadaProvincial = new FrmProvincial();
            resultado = llamadaProvincial.ShowDialog();

            if (resultado == DialogResult.OK) {

                centralita += llamadaProvincial.LlamadaProp;
                lstVisor.Items.Add(DatosLlamada(llamadaProvincial.LlamadaProp));

            }

        }

        private string DatosLlamada(Llamada llamada) {

            return llamada.ToString();

        }

        private void cboOrdenamiento_SelectedIndexChanged(object sender, EventArgs e) {

            switch (cboOrdenamiento.Text) {
                
                case "Ascendente":
                    this.criterio = ECriterio.Ascendente;
                    break;
                case "Descendente":
                    this.criterio = ECriterio.Descendente;
                    break;
            }

            centralita.OrdenarLlamadas(Llamada.OrdenarPorDuracion);

        }

    }
}
