﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Centralita;

namespace CentralitaWindowsForms {

    public partial class FrmLlamada : Form {

        private Llamada llamada;

        public FrmLlamada() {

            InitializeComponent();

        }

        public virtual Llamada LlamadaProp {

            get {

                return this.llamada;

            }

        }

        protected virtual void btnAceptar_Click(object sender, EventArgs e) {

            float duracion;

            if (txtOrigen.Text != "" && txtDestino.Text != "" && txtDuracion.Text != "") { 
            
                if (float.TryParse(txtDuracion.Text, out duracion)) {
                    
                    llamada = new Llamada(txtOrigen.Text, txtDestino.Text, duracion);

                }

            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;

        }

        protected void btnCancelar_Click(object sender, EventArgs e) {

            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;

        }

    }

}
