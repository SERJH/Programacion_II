﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Centralita {

    public class Local : Llamada {

        protected float _costo;

        public float CostoLlamada {

            get {

                return this.CalcularCosto();

            }

        }

        private float CalcularCosto() { 
        
            return this.Duracion * this._costo;

        }

        public Local(Llamada unaLLamada, float costo):this(unaLLamada.NroOrigen, unaLLamada.Duracion, unaLLamada.NroDestino, costo) { 
        
            

        }

        public Local(string origen, float duracion, string destino, float costo):base(origen, destino:destino, duracion:duracion) {

            this._costo = costo;

        }

        protected override string Mostrar() {
        
            return base.Mostrar() + 
                   "\nCosto de llamada: " + this.CostoLlamada;

        }

        public override string ToString() {

            return this.Mostrar();

        }

        public override bool Equals(object obj) {

            return obj is Local;

        }

    }
}
