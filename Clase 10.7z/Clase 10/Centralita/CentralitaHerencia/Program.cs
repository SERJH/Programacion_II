﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Centralita;

namespace CentralitaHerencia {

    class Program {

        static void Main(string[] args) {

            Centralita Telefonica = new Centralita();

            Local llamadaUno = new Local("444", 30, "222", 2.65f);
            Provincial llamadaDos = new Provincial("555", Franja.Franja_1, 21, "888");
            Local llamadaTres = new Local("464", 45, "111", 1.99f);
            Provincial llamadaCuatro = new Provincial(Franja.Franja_3, llamadaDos);

            Telefonica.Llamadas.Add(llamadaUno);
            Console.WriteLine(Telefonica.Mostrar());
            Telefonica.Llamadas.Add(llamadaDos);
            Console.WriteLine(Telefonica.Mostrar());
            Telefonica.Llamadas.Add(llamadaTres);
            Console.WriteLine(Telefonica.Mostrar());
            Telefonica.Llamadas.Add(llamadaCuatro);
            Console.WriteLine(Telefonica.Mostrar());

            Console.WriteLine("Se ordenaran las llamadas");

            Telefonica.OrdenarLlamadas(ECriterio.Descendente);

            Console.WriteLine(Telefonica.Mostrar());

            Console.Read();

        }
    }
}
