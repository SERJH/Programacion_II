﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase06.Entidad;

namespace App1 {

    class Program {

        static void Main(string[] args) {

            Tempera temp = new Tempera(ConsoleColor.Magenta, "Filgo", 10);
            Tempera temp2 = new Tempera(ConsoleColor.Magenta, "Filgo", 8);
            Tempera temp3 = new Tempera(ConsoleColor.Red, "Abbf", 56);

            if (temp == temp2) {

                Console.WriteLine("Son iguales");
            
            }

            if (temp == temp3) {

                Console.WriteLine("Son iguales");

            } else {

                Console.WriteLine("Son distintos");

            }
            Console.WriteLine(Tempera.Mostrar(temp));
            Console.WriteLine(Tempera.Mostrar(temp+10));
            Console.WriteLine(Tempera.Mostrar(temp+10));
            Console.WriteLine(Tempera.Mostrar(temp+20));
            Console.Write(Tempera.Mostrar(temp));

            ////////////////////////////////////////////

            Paleta p = 8;

            /*string s = (string)p;

            Console.WriteLine(s);*/
            Console.Read();



        }

    }

}
