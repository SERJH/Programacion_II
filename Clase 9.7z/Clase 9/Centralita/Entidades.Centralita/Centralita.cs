﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Centralita {

    public class Centralita {

        private List<Llamada> _listaDeLlamadas;
        protected string _razonSocial;

        public float GananciaPorLocal {

            get {

                return this.CalcularGanancia(TipoLlamada.Local);

            }

        }

        public float GananciaPorProvincial {

            get {

                return this.CalcularGanancia(TipoLlamada.Provincial);

            }

        }

        public float GananciaTotal {

            get {

                return this.CalcularGanancia(TipoLlamada.Todas);

            }

        }

        public List<Llamada> Llamadas {

            get {

                return this._listaDeLlamadas;

            }

        }

        private float CalcularGanancia(TipoLlamada tipo) {

            float retorno = 0;
            Local llamadaLocal;
            Provincial llamadaProvincial;

            switch (tipo) {
                case TipoLlamada.Local:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Local) { 
                        
                        llamadaLocal = (Local)i;
                        retorno += (llamadaLocal.Duracion * llamadaLocal.CostoLlamada);

                        }           

                    }

                    break;

                case TipoLlamada.Provincial:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Provincial) {

                            llamadaProvincial = (Provincial)i;
                            retorno += (llamadaProvincial.Duracion * llamadaProvincial.CostoLlamada);

                        }

                    }

                    break;

                case TipoLlamada.Todas:

                    foreach (Llamada i in this._listaDeLlamadas) {

                        if (i is Local) {

                            llamadaLocal = (Local)i;
                            retorno += (llamadaLocal.Duracion * llamadaLocal.CostoLlamada);

                        } else {

                            llamadaProvincial = (Provincial)i;
                            retorno += (llamadaProvincial.Duracion * llamadaProvincial.CostoLlamada);

                        }

                    }

                    break;

            }

            return retorno;

        }

        public Centralita() {

            this._listaDeLlamadas = new List<Llamada>();

        }

        public Centralita(string nombreEmpresa):this() {

            this._razonSocial = nombreEmpresa;

        }

        public string Mostrar() {

            StringBuilder sb = new StringBuilder();

            sb.Append("\nRazon social: ");
            sb.AppendLine(this._razonSocial);
            sb.Append("Ganancia total: ");
            sb.AppendLine(this.GananciaTotal.ToString());
            sb.Append("Ganancias locales: ");
            sb.AppendLine(this.GananciaPorLocal.ToString());
            sb.Append("Ganancias provinciales: ");
            sb.AppendLine(this.GananciaPorProvincial.ToString());
            sb.AppendLine("Detalle de las llamadas realizadas: ");

            foreach (Llamada i in this._listaDeLlamadas) {

                sb.AppendLine(i.Mostrar());

            }

            return sb.ToString();

        }

        public void OrdenarLlamadas() {

            for (int i = 0; i < (this._listaDeLlamadas.Count - 1); i++) {

                for (int j = i + 1; j <= (this._listaDeLlamadas.Count - 1); j++) {

                    Llamada.OrdenarPorDuracion(this._listaDeLlamadas[i], this._listaDeLlamadas[j]);

                }

            }

        }

    }
}
