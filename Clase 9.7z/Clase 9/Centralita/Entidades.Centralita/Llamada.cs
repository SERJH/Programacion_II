﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Centralita {

    public class Llamada {

        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;

        public float Duracion {

            get {

                return this._duracion;

            }

        }

        public string NroDestino {

            get {

                return this._nroDestino;

            }

        }

        public string NroOrigen {

            get {

                return this._nroOrigen;

            }

        }

        public Llamada(string origen, string destino, float duracion) {

            this._nroOrigen = origen;
            this._nroDestino = destino;
            this._duracion = duracion;

        }

        public string Mostrar() { 
        
            return "\nOrigen: " + this._nroOrigen +
                   "\nDestino: " + this._nroDestino +
                   "\nDuracion: " + this._duracion;

        }

        public static int OrdenarPorDuracion(Llamada llamadaUno, Llamada llamadaDos) {

            int retorno = 0;

            if (llamadaUno.Duracion > llamadaDos.Duracion) {

                retorno = 1;

            } else if (llamadaUno.Duracion < llamadaDos.Duracion) {

                retorno = -1;

            }

            return retorno;

        }

    }

}
