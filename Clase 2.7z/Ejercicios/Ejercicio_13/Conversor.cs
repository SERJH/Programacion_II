﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13 {

    class Conversor {

        public static string DecimalBinario(double numero) {
        
            string retorno = " ";

            retorno = Convert.ToString(BitConverter.DoubleToInt64Bits(numero), 2);

            return retorno;

        }

        public static double BinarioDecimal(string numero) {
        
            double retorno = 0;

            retorno = BitConverter.Int64BitsToDouble(Convert.ToInt32(numero, 2));

            return retorno;

        }

    }

}
