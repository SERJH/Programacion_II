﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13 {

    class Program {

        static void Main(string[] args) {

            string testDecimalBinario;
            double testBinarioDecimal;

            testBinarioDecimal = Conversor.BinarioDecimal("1010101");
            testDecimalBinario = Conversor.DecimalBinario(132.44);
            Console.WriteLine("Binario a decimal: {0}", testBinarioDecimal);
            Console.WriteLine("Decimal a binario: {0}", testDecimalBinario);
            Console.ReadLine();

        }

    }

}
