﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_7
{

    class Ejercicio_7
    {

        static void Main(string[] args)
        {

            int year;
            int month;
            int day = 0;
            int diasVividos = 0;
            int yearNow;
            int monthNow;
            int dayNow;
            int i;
            int j;
            int h;
            bool firstDay = true;
            bool firstMonth = true;
            string dato;

            Console.Title = "Ejercicio numero 7";

            Console.Write("Ingrese su año de nacimiento: ");
            dato = Console.ReadLine();

            while (!int.TryParse(dato, out year) || year < 1800)
            {

                Console.Write("Entrada invalida. Reingrese: ");
                dato = Console.ReadLine();

            }

            Console.Write("Ingrese su mes de nacimiento: ");
            dato = Console.ReadLine();

            while (!int.TryParse(dato, out month) || month < 1 || month > 12)
            {

                Console.Write("Entrada invalida. Reingrese: ");
                dato = Console.ReadLine();

            }

            Console.Write("Ingrese su dia de nacimiento: ");
            dato = Console.ReadLine();

            switch (month)
            {

                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:

                    while (!int.TryParse(dato, out day) || day < 1 || day > 31)
                    {

                        Console.Write("Entrada invalida. Reingrese: ");
                        dato = Console.ReadLine();

                    }

                    break;

                case 4:
                case 6:
                case 9:
                case 11:

                    while (!int.TryParse(dato, out day) || day < 1 || day > 30)
                    {

                        Console.Write("Entrada invalida. Reingrese: ");
                        dato = Console.ReadLine();

                    }

                    break;

                case 2:

                    if (esBisiesto(year))
                    {

                        while (!int.TryParse(dato, out day) || day < 1 || day > 29)
                        {

                            Console.Write("Entrada invalida. Reingrese: ");
                            dato = Console.ReadLine();

                        }

                    }
                    else
                    {

                        while (!int.TryParse(dato, out day) || day < 1 || day > 28)
                        {

                            Console.Write("Entrada invalida. Reingrese: ");
                            dato = Console.ReadLine();

                        }

                    }

                    break;

            }

            dayNow = DateTime.Now.Day;
            monthNow = DateTime.Now.Month;
            yearNow = DateTime.Now.Year;

            for (i = year; i <= yearNow; i++)
            {

                // CALCULO AÑOS

                if (i == yearNow)
                {

                    // SI ESTA EN EL AÑO ACTUAL

                    if (firstMonth)
                    {

                        // SI ES EL PRIMER CALCULO DE MES

                        for (j = month; j <= monthNow; j++)
                        {

                            // CALCULO MESES

                            if (j == monthNow)
                            {

                                // SI ESTA EN EL MES ACTUAL

                                if (firstDay)
                                {

                                    // SI ES EL PRIMER CALCULO DE DIA

                                    for (h = day; h <= dayNow; h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                    firstDay = false;

                                }
                                else
                                {

                                    // SI NO ES EL PRIMER CALCULO DE DIA

                                    for (h = 1; h <= dayNow; h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                }

                            }
                            else
                            {

                                // SI NO ESTA EN EL MES ACTUAL

                                if (firstDay)
                                {

                                    // SI ES EL PRIMER CALCULO DE DIA

                                    for (h = day; h <= DateTime.DaysInMonth(i, j); h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                    firstDay = false;

                                }
                                else
                                {

                                    // SI NO ES EL PRIMER CALCULO DE DIA

                                    for (h = 1; h <= DateTime.DaysInMonth(i, j); h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                }

                            }


                        }

                    }
                    else
                    {

                        // SI NO ES EL PRIMER CALCULO DE MES

                        for (j = 1; j <= monthNow; j++)
                        {

                            // CALCULO MESES

                            if (j == monthNow)
                            {

                                // SI ES EL MES ACTUAL

                                if (firstDay)
                                {

                                    // SI ES EL PRIMER CALCULO DE DIA

                                    for (h = day; h <= dayNow; h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                    firstDay = false;

                                }
                                else
                                {

                                    // SI NO ES EL PRIMER CALCULO DE DIA

                                    for (h = 1; h <= dayNow; h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                }

                            }
                            else
                            {

                                // SI NO ES EL MES ACTUAL

                                if (firstDay)
                                {

                                    // SI ES EL PRIMER CALCULO DE DIA

                                    for (h = day; h <= DateTime.DaysInMonth(i, j); h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                    firstDay = false;

                                }
                                else
                                {

                                    // SI NO ES EL PRIMER CALCULO DE DIA

                                    for (h = 1; h <= DateTime.DaysInMonth(i, j); h++)
                                    {

                                        // CALCULO DIAS

                                        diasVividos++;

                                    }

                                }

                            }

                        }

                    }

                }
                else
                {

                    // SI NO ES EL AÑO ACTUAL

                    if (firstMonth)
                    {

                        // SI NO ES EL PRIMER CALCULO DE MES

                        for (j = month; j <= 12; j++)
                        {

                            // CALCULO MESES

                            if (firstDay)
                            {

                                // SI ES EL PRIMER CALCULO DE DIA

                                for (h = day; h <= DateTime.DaysInMonth(i, j); h++)
                                {

                                    // CALCULO DIAS

                                    diasVividos++;

                                }

                                firstDay = false;

                            }
                            else
                            {

                                // SI NO ES EL PRIMER CALCULO DE DIA

                                for (h = 1; h <= DateTime.DaysInMonth(i, j); h++)
                                {

                                    // CALCULO DIAS

                                    diasVividos++;

                                }

                            }

                        }

                        firstMonth = false;

                    }
                    else
                    {

                        // SI NO ES EL PRIMER CALCULO DE MES

                        for (j = 1; j <= 12; j++)
                        {

                            // CALCULO MESES

                            if (firstDay)
                            {

                                // SI ES EL PRIMER CALCULO DE DIA

                                for (h = day; h <= DateTime.DaysInMonth(i, j); h++)
                                {

                                    // CALCULO DIAS

                                    diasVividos++;

                                }

                                firstDay = false;

                            }
                            else
                            {

                                // SI NO ES EL PRIMER CALCULO DE DIA

                                for (h = 1; h <= DateTime.DaysInMonth(i, j); h++)
                                {

                                    // CALCULO DIAS

                                    diasVividos++;

                                }

                            }

                        }

                    }

                }

            }

            Console.Write("Cantidad de dias vividos: {0}", diasVividos);
            Console.Read();

        }

        static bool esBisiesto(int year)
        {

            bool bisiesto = false;

            if ((year % 4) == 0)
            {

                bisiesto = true;

                if ((year % 100) == 0 && (year % 400) == 0)
                {

                    bisiesto = true;

                }
                else
                {

                    bisiesto = false;

                }

            }

            return bisiesto;

        }

    }

}
