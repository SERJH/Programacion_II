﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12 {

    class ValidarRespuesta {

        public static bool ValidaS_N() {

            bool respuesta = false;

            string dato;

            Console.Write("¿Continua? (S/N): ");
            dato = Console.ReadLine();

            while (string.Compare(dato.ToLower(), "s") != 0 && string.Compare(dato.ToLower(), "n") != 0) {

                Console.Write("Entrada invalida. Reingrese: ");
                dato = Console.ReadLine();

            }

            if (string.Compare(dato.ToLower(), "s") == 0) {

                respuesta = true;

            } else {

                respuesta = false;

            }

            return respuesta;

        }

    }

}
