﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12 {

    class Program {

        static void Main(string[] args) {

            int numero;
            int suma = 0;
            string dato;
            bool seguir = true;

            Console.Write("Se ingresaran numeros hasta que se indique que no se quieran ingresar mas\n");
            Console.ReadLine();
            Console.Clear();

            while (seguir) {

                Console.Write("Ingrese un numero: ");
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out numero)) {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();

                }

                Console.Clear();

                seguir = ValidarRespuesta.ValidaS_N();
                suma += numero;

            }

            Console.Write("La suma total fue: {0}", suma);
            Console.Read();

        }

    }

}
