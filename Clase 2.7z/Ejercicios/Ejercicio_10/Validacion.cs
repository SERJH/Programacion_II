﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11 {

    class Validacion {

        public static bool Validar(int num, int min, int max) {

            bool validado = false;

            if (num >= min && num <= max) {

                validado = true;

            } 

            return validado;

        }

    }

}
