﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11 {

    class Program {

        static void Main(string[] args) {

            int numero;
            int minValidar = -100;
            int maxValidar = 100;
            int min = 0;
            int max = 0;
            int cantidad = 10;
            int i;
            int suma = 0;
            float prom;
            string dato;

            Console.WriteLine("Se ingresaran {0} numeros, presione enter para comenzar", cantidad);
            Console.ReadLine();
            Console.Clear();

            for (i = 0; i < cantidad; i++) {

                Console.Write("Ingrese el numero {0}: ", (i + 1));
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out numero) || !Validacion.Validar(numero, minValidar, maxValidar)) {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();
                
                }

                Console.Clear();

                if (i == 0) {

                    min = numero;
                    max = numero;

                } else if (numero < min) {

                    min = numero;

                } else if (numero > max) {

                    max = numero;

                }

                suma += numero;

            }

            prom = ((float)suma / cantidad);

            Console.WriteLine("El mayor fue: {0}", max);
            Console.WriteLine("El menor fue: {0}", min);
            Console.WriteLine("El promedio fue: {0}", prom);
            Console.Read();

        }

    }

}
