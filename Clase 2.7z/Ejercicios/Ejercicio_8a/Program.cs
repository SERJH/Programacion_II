﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_8
{

    class Ejercicio_8
    {

        static void Main(string[] args)
        {
 
            int cantidad;
            int i;            
            float descuento = 0.87f;
            string dato;

            Console.Title = "Ejercicio numero 8";

            Console.Write("Ingrese la cantidad de empleados que se ingresaran: ");
            dato = Console.ReadLine();

            while (!int.TryParse(dato, out cantidad) || cantidad < 1)
            {

                Console.Write("Entrada invalida. Reingrese: ");
                dato = Console.ReadLine();

            }

            Console.Clear();

            string[] nombres = new string[cantidad];
            int[] valoresHora = new int[cantidad];
            int[] antiguedades = new int[cantidad];
            int[] cantHorasMes = new int[cantidad];
            float[] importesACobrarBruto = new float[cantidad];
            float[] importesACobrarNeto = new float[cantidad];

            for (i = 0; i < cantidad; i++)
            {

                Console.Write("Ingrese el nombre del empleado numero {0}: ", (i + 1));
                nombres[i] = Console.ReadLine();

                Console.Clear();

                Console.Write("Ingrese el valor hora de {0}: ", (nombres[i]));
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out valoresHora[i]) || valoresHora[i] < 1)
                {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();

                }

                Console.Clear();

                Console.Write("Ingrese la antiguedad de {0}: ", (nombres[i]));
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out antiguedades[i]) || antiguedades[i] < 1)
                {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();

                }

                Console.Clear();

                Console.Write("Ingrese las horas trabajadas en el mes de {0}: ", (nombres[i]));
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out cantHorasMes[i]) || cantHorasMes[i] < 1)
                {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();

                }

                Console.Clear();

            }

            Console.WriteLine("NOMBRE\tANTIG\tV/HORA\tC/BRUTO\tDESCU\tC/NETO\n");

            for (i = 0; i < cantidad; i++)
            {

                importesACobrarBruto[i] = (valoresHora[i] * cantHorasMes[i]);
                importesACobrarBruto[i] += (antiguedades[i] * 150);
                importesACobrarNeto[i] = importesACobrarBruto[i] * descuento;
     
                Console.Write("{0}\t{1}\t{2}\t{3:C}\t{4}\t{5:C}\n", nombres[i], antiguedades[i], valoresHora[i], importesACobrarBruto[i], "13%", importesACobrarNeto[i]);

            }

            Console.Read();

        }

    }

}
