﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app1 {

    class Persona {

        public static void saludar() {

            Console.WriteLine("Holi");

        }

        public void saludar2() {

            Console.WriteLine("Holu");

        }

    }

}
