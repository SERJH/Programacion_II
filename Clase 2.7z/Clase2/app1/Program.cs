﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app1 {

    class Program {

        static void Main(string[] args) {

            Persona.saludar();

            Persona saludin = new Persona();
            saludin.saludar2();
            Console.Read();

        }

    }

}
